import 'package:flutter/material.dart';

const kHead1 = TextStyle(
  fontFamily: '',
  fontSize: 20,
  color: Colors.black,
);