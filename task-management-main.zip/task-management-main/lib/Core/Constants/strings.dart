
const title = 'Flutter Todo app';
const welcomeMsg = 'Welcome to HAZTASK';