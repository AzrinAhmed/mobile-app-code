import 'package:flutter/material.dart';

const Color kPrimaryColor = Color(0xff7E55C2);
const Color kSecondaryColor = Color(0xffFC9C2B);
const Color kWhite = Color(0xffffffff);
const Color kBlack = Color(0xff000000);
const Color kBGColor = Color(0xFFEEEFF5);