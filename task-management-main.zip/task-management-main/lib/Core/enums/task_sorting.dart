enum TaskSortOption {
  none,
  dueDate,
  creationDate,
}
