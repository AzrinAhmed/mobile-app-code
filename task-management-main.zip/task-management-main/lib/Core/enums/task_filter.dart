enum TaskFilter {
  all,
  done,
  pending,
}
